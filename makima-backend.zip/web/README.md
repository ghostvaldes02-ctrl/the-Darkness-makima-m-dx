 # 🌑 𝗠𝗔𝗞𝗜𝗠𝗔 𝗠-𝗗𝗫

Un bot WhatsApp avancé basé sur la bibliothèque **Baileys**, conçu pour la gestion de groupes, l’automatisation, le téléchargement de médias et bien plus encore.  
> *L’ombre veille sur toi.*

<div align="center"> 
  <a href="https://git.io/typing-svg"> 
    <img src="https://readme-typing-svg.demolab.com?font=Ribeye&size=50&pause=1000&color=6600cc&center=true&width=910&height=100&lines=MAKIMA+M-DX;Darkness+X-MD;Coded+By+The+Darkness" alt="Typing SVG" />
  </a> 
</div> 

<div align="center"> 
  <a href="https://whatsapp.com/channel/0029VbBz3AYBPzjd5is5mJ2W"> 
    <img src="https://files.catbox.moe/g7tyh7.jpg" alt="MAKIMA M-DX" height="300"> 
  </a> 
</div>

<div align="center">
  <img src="https://img.shields.io/github/followers/Danscot?style=for-the-badge&label=Followers" alt="Followers"/>
  <img src="https://img.shields.io/github/stars/Danscot/makima-mdx?style=for-the-badge&label=Stars" alt="Stars"/>
  <img src="https://img.shields.io/github/forks/Danscot/makima-mdx?style=for-the-badge&label=Forks" alt="Forks"/>
  <img src="https://img.shields.io/github/watchers/Danscot/makima-mdx?style=for-the-badge&label=Watchers" alt="Watchers"/>
</div>

---

## 🖤 Aperçu du menu

```

┏━━━━━━━━━━━━━━━━━━━━┓
┃    𓁢 𝙈𝘼𝙆𝙄𝙈𝘼 𝙈-𝘿𝙓 𓁢
┃    𝗟'𝗼𝗺𝗯𝗿𝗲 𝘃𝗲𝗶𝗹𝗹𝗲 𝘀𝘂𝗿 𝘁𝗼𝗶
┗━━━━━━━━━━━━━━━━━━━━┛

◈ 𝑷𝒓𝒆́𝒇𝒊𝒙 : .
◈ 𝑼𝒕𝒊𝒍𝒊𝒔𝒂𝒕𝒆𝒖𝒓 : <votre nom>
◈ 𝑱𝒐𝒖𝒓 : <jour>
◈ 𝑫𝒂𝒕𝒆 : <date>
◈ 𝑽𝒆𝒓𝒔𝒊𝒐𝒏 : 5.2.0
◈ 𝑪𝒐𝒎𝒎𝒂𝒏𝒅𝒆𝒔 : 60+
◈ 𝑻𝒚𝒑𝒆 : 𝗫-𝗠𝗗

▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
𝗠𝗘𝗡𝗨𝗦
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

🌑 𝗨𝗧𝗜𝗟𝗜𝗧𝗔𝗜𝗥𝗘𝗦
› ping      › getid
› owner     › device
› sudo      › getsudo
› delsudo   › test
› bugmenu   › getnewsid

⚙️ 𝗖𝗢𝗡𝗙𝗜𝗚𝗨𝗥𝗔𝗧𝗜𝗢𝗡
› setprefix › welcome
› setonline › setpp
› getpp     › autorecord
› autotype  › autoreact
› statuslike› getconfig
› respons   › settag

👥 𝗚𝗥𝗢𝗨𝗣𝗘
› kick      › kickall
› promote   › demote
› promoteall› demoteall
› purge     › mute
› unmute    › bye
› gclink    › add
› resetlink

🎴 𝗠𝗘𝗗𝗜𝗔
› sticker   › vv
› save      › photo
› toaudio   › take
› url       › video

⬇️ 𝗧𝗘𝗟𝗘𝗖𝗛𝗔𝗥𝗚𝗘𝗠𝗘𝗡𝗧
› img       › play
› tiktok    › pinterest

🏷️ 𝗧𝗔𝗚𝗦
› tag       › tagall
› tagadmin  › tagoption

🛡️ 𝗦𝗘𝗖𝗨𝗥𝗜𝗧𝗘
› block     › unblock
› warning   › unwarn
› antidlt   › antispam
› antipromote › antidemote

▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
𝗣𝗢𝗪𝗘𝗥𝗘𝗗 𝗕𝗬 The Darkness
𝗗𝗮𝗿𝗸𝗻𝗲𝘀𝘀 𝗫-𝗠𝗗
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

```

---

## ⚡ Installation

1. **Cloner le dépôt :**
   ```bash
   git clone https://github.com/Danscot/makima-mdx.git
   cd makima-mdx
```

1. Installer les dépendances :
   ```bash
   npm install
   ```
2. Lancer le bot :
   ```bash
   npm start
   ```

---

🔑 Authentification

· Utilise le mode appairage (pairing code) pour connecter ton compte WhatsApp.
· Support des multi-sessions (plusieurs comptes).
· Possibilité d’utiliser Telegram pour le pairing.

---

🛡 Notes & conseils

· Commandes d’administration : kick, promote, demote, purge, etc. nécessitent que le bot soit admin du groupe.
· Médias : Le menu envoie une image et un audio pour une expérience immersive.
· Usage responsable : Conçu à des fins éducatives et personnelles. Évite le spam.
· Préfixe personnalisé : Chaque utilisateur peut changer son préfixe avec .setprefix.

---

📜 Licence

MIT License – Libre d’utilisation, de modification et de redistribution.

---

🙌 Contributions

Les contributions, rapports de bugs et demandes de fonctionnalités sont les bienvenus.
Merci de consulter la section Issues.

---

🌟 Support

Si ce projet vous est utile, n’hésitez pas à lui donner une ⭐️ étoile sur GitHub.

---

Crédits

· The Darkness – Créateur du bot
· Baileys – Bibliothèque WhatsApp Web
· TechGod143 & Dgxeon – Inspiration pour le mode pairing

---

⚠️ Avertissement important

Note : Ce bot est créé à des fins éducatives uniquement.
Ce n’est PAS un bot officiel WhatsApp. L’utilisation de ce bot peut entraîner le bannissement de votre compte WhatsApp. Utilisez-le à vos propres risques. Les développeurs ne pourront être tenus responsables des conséquences ou des interdictions pouvant survenir lors de l’utilisation de ce bot.

📝 Légal

· Ce projet n’est pas affilié, autorisé, maintenu, parrainé ou approuvé par WhatsApp ou l’une de ses filiales ou sociétés affiliées.
· Il s’agit d’un logiciel indépendant et non officiel. À utiliser à vos risques et périls.
· Ne spammez pas les gens avec ce bot.
· N’utilisez pas ce bot pour envoyer des messages en masse ou à des fins illégales.
· Les développeurs déclinent toute responsabilité en cas d’utilisation abusive ou de dommages causés par ce programme.

Licence

Ce projet est sous licence MIT. Cependant, vous devez :

· Utiliser ce logiciel conformément à toutes les lois et réglementations applicables
· Inclure la licence originale et les avis de droit d’auteur
· Créditer les auteurs originaux
· Ne pas l’utiliser pour du spam ou des activités malveillantes

📜 Copyright

Copyright (c) 2025 The Darkness. Tous droits réservés.

Ce projet contient du code provenant de divers projets open source :

· Baileys (Licence MIT)
· Autres bibliothèques listées dans package.json

---

🔗 Liens officiels :

· Chaîne WhatsApp
· Groupe Telegram

